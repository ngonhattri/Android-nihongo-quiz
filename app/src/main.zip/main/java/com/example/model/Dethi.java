package com.example.model;

public class Dethi {
    private String Name;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public Dethi() {
    }

    public Dethi(String name) {
        Name = name;
    }
}
